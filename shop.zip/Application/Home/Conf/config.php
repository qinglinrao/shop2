<?php
return array(
	//'配置项'=>'配置值'

	// 设置相关文件路径
	'TMPL_PARSE_STRING' => array(
		'__PUBLIC__' => __ROOT__ .'/public',
		'__STATIC__' => __ROOT__ .'/Public/static',
		'__EDITOR__' => __ROOT__ .'/Public/editor',
		'__HIMG__' => __ROOT__ .'/Public/Home/images/',
		'__HJS__' => __ROOT__ .'/Public/Home/js/',
		'__HCSS__' => __ROOT__ .'/Public/Home/css/',
		'__UPGOODSIMG__' => __ROOT__ .'/Uploads/Goods/',

			'__GIMG__' => __ROOT__ .'/Public/Goods/img/',
			'__GJS__' => __ROOT__ .'/Public/Goods/js/',
			'__GCSS__' => __ROOT__ .'/Public/Goods/css/',
	),
);