<?php
namespace Admin\Controller;
use Think\Controller;

class IndexController extends CommonController {

    public function main() {
        echo 'welcome to background management center!';
    }

}